/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.student.crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ashutosh
 */
public class StudentDao {
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3307/classes?useSSL=false","root","root");
        }
        catch(Exception e){
            System.out.println(e);
        }
        return con;
    }
    
    public static int save(Student student){
        int status= 0;
        
        try{
            Connection con=StudentDao.getConnection();
            PreparedStatement ps= con.prepareStatement("insert into student(name,age) values (?,?)");
            ps.setString(1, student.getName());
            ps.setString(2, student.getAge());
            
            status  = ps.executeUpdate();
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        return  status;
        
    }
    
    public static int update(Student student){  
        int status = 0; 
        
        try{  
            Connection con = StudentDao.getConnection();
            
            PreparedStatement ps = 
            		con.prepareStatement("update students set name=?, age=? where id=?");  
            ps.setString(1, student.getName());  
            ps.setString(2, student.getAge());  
            ps.setInt(3, student.getId());  
              
            status = ps.executeUpdate();  
              
            con.close();  
        }
        catch(Exception ex){
        	   System.out.println(ex);
        }  
          
        return status;  
    } 
    
    public static int delete(int id){  
        int status = 0;  
        
        try{  
            Connection con = StudentDao.getConnection();  
            
            PreparedStatement ps = con.prepareStatement("delete from student where id=?");  
            ps.setInt(1, id);  
            
            status = ps.executeUpdate();  
              
            con.close();  
        }
        catch(Exception e){
        	e.printStackTrace();
        }  
          
        return status;  
    }  
    
    public static Student getStudentById(int id){  
        Student student = new Student();  
          
        try{  
            Connection con = StudentDao.getConnection(); 
            
            PreparedStatement ps = con.prepareStatement("select * from students where id=?");  
            ps.setInt(1, id);  
            
            ResultSet rs = ps.executeQuery();  
            if(rs.next()){  
            	student.setId(rs.getInt(1));  
            	student.setName(rs.getString(2));  
            	student.setAge(rs.getString(3));                
            }
            
           
            con.close();  
        }
        catch(Exception ex){
        	ex.printStackTrace();
        }  
          
        return student;  
    } 
    
    public static List<Student> getAllStudents(){  
        List<Student> list = new ArrayList<Student>();  
          
        try{  
            Connection con = StudentDao.getConnection();  
            
            PreparedStatement ps = con.prepareStatement("select * from student");  
            
            ResultSet rs = ps.executeQuery();  
            while(rs.next()){  
                Student student = new Student();  
                student.setId(rs.getInt(1));  
                student.setName(rs.getString(2));  
                student.setAge(rs.getString(3));  
                list.add(student);  
            }  
            
            con.close();  
        }
        catch(Exception e){
        	e.printStackTrace();
        }  
          
        return list;
    }  
}
